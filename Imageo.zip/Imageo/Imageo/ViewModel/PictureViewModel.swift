//
//  PictureViewModel.swift
//  Imageo
//
//  Created by Yomi on 3/29/23.
//

import Foundation

class PictureViewModel: ObservableObject{
    
    @Published var pictures: [PictureModel] = [] {
        
        //anytime there is a change called on the ItemModel, the 'didset' is called to save items
        didSet{
//            saveItem()
        }
    }
    
    init(){
//        getItems()
    }
    
    func addItem(text: String){
        let newItem = PictureModel(name: text)
        pictures.append(newItem)
    }
}
