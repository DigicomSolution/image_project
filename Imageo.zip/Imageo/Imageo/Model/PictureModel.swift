//
//  PictureModel.swift
//  Imageo
//
//  Created by Yomi on 3/29/23.
//

import Foundation

//conform to identifiable and codable
struct PictureModel: Identifiable, Codable{
    let id: String
    let name: String
    
    init(id: String = UUID().uuidString, name: String) {
        self.id = id
        self.name = name
    }
    
    func updateModel() -> PictureModel{
        return PictureModel(id: id, name: name)
    }
}
