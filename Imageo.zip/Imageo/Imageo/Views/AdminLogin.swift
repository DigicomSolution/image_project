//
//  AdminLogin.swift
//  Imageo
//
//  Created by Yomi on 3/29/23.
//

import SwiftUI

final class SignInEmailViewModel: ObservableObject{
    @Published var email = ""
    @Published var password = ""
    
    
    
    func signup() {
        guard !email.isEmpty, !password.isEmpty else{
            print("No email or password found")
            return
        }
        
        Task{
            do{
                let returnedDataResult = try await AuthenticationManager.shared.createUser(email: email, password: password)
                print("Success")
                print(returnedDataResult)
            }catch{
                print("Error: \(error)")
            }
        }
    }
    
    func signin() async throws{
        guard !email.isEmpty, !password.isEmpty else{
            print("No email or password found")
            return
        }
        
        try await AuthenticationManager.shared.signIn(email: email, password: password)

        
    }
    
}

struct AdminLogin: View {
    
    @StateObject var viewModel = SignInEmailViewModel()
    @Binding var showSignInView: Bool
    
    var body: some View {
        ZStack{
            //background
            RadialGradient(
                gradient: Gradient(colors: [Color.purple, Color.cyan]),
                center: .topLeading,
                startRadius: 1,
                endRadius: UIScreen.main.bounds.height
            )
            .ignoresSafeArea()
            
            VStack(spacing: 20) {
                
                HStack{
                    Image(systemName: "lock.shield")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 30, height: 30)
                        .foregroundColor(.white)
                    Text("Login")
                        .font(.title)
                        .fontWeight(.heavy)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                
                TextField("Email", text: $viewModel.email)
                    .padding(.horizontal)
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .frame(height: 55)
                    .background(.white)
                    .cornerRadius(10)
                
                SecureField("Password", text: $viewModel.password)
                    .padding(.horizontal)
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .frame(height: 55)
                    .background(.white)
                    .cornerRadius(10)
                
                
                Button {
                    Task{
                        do{
                            try await viewModel.signin()
                            showSignInView = false
                        }catch{
                            print("Error \(error)")
                        }
                    }
                    
                } label: {
                    Text("Login")
                        .foregroundColor(.white)
                        .fontWeight(.bold)
                        .frame(height: 55)
                        .frame(maxWidth: .infinity)
                        .background(.purple)
                        .cornerRadius(10)
                }
            }
            .padding()
            
        }
        

    }
}

struct AdminLogin_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack{
            RootView()
        }
    }
}
