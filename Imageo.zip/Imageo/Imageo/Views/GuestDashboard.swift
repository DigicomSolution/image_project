//
//  GuestDashboard.swift
//  Imageo
//
//  Created by Yomi on 3/29/23.
//

import SwiftUI
import Firebase
import FirebaseStorage




struct GuestDashboard: View {
    
    let defaultUrl: String = "https://firebasestorage.googleapis.com/v0/b/imageoswiftapp.appspot.com/o/pictures"
    
    func listAllFiles(){
        let storage = Storage.storage()
        let storageRef = storage.reference().child("pictures")
//        storageRef.downloadURL { URL, error in
//            if error != nil {
//                print("My Error \((error?.localizedDescription)!)")
//                return
//            }
//            print("Download success \(String(describing: URL))")
//        }
        
        storageRef.listAll { (result, error) in
                if let error = error {
                        print("Error while listing all files: ", error)
                }

                for item in result!.items {

                        print("Item in images folder: ", item)
                }
        }
    }
    
    
    var body: some View {
        ZStack{
            //background
            RadialGradient(
                gradient: Gradient(colors: [Color.white, Color.gray]),
                center: .topLeading,
                startRadius: 1,
                endRadius: UIScreen.main.bounds.height
            )
            .ignoresSafeArea()
            
            VStack{
                Divider()
                    .foregroundColor(.white)
                Button {
                    listAllFiles()
                } label: {
                    Text("List in console")
                }

                
                
                Spacer()
                
        
            }
            .navigationBarItems(
                trailing: HStack{
                    Image(systemName: "gearshape.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 20, height: 20)
                        .foregroundColor(.blue)
                    Text("Settings")
                        .font(.headline)
                        .foregroundColor(.blue)
                })
            
        }
    }
}

struct GuestDashboard_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack{
            GuestDashboard()
        }
        
    }
}

