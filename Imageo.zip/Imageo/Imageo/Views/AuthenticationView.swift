//
//  ContentView.swift
//  Imageo
//
//  Created by Yomi on 3/29/23.
//

import SwiftUI

struct AuthenticationView: View {
    
    @Binding var showSignInView: Bool
    
    var body: some View {
        
        NavigationView {
            ZStack{
                //background
                RadialGradient(
                    gradient: Gradient(colors: [Color.purple, Color.cyan]),
                    center: .topLeading,
                    startRadius: 1,
                    endRadius: UIScreen.main.bounds.height
                )
                .ignoresSafeArea()
                //content
                VStack {
                    Spacer()
                    
                    Image(systemName: "photo.fill.on.rectangle.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 200)
                        .foregroundColor(.white)
                    
                    Text("Explore Live Photos")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                        .bold()
                    
                    Text("The #1 place to find live photos and explore real world photographic pictures. Download directly to your phone, use as frames and share with friends")
                        .font(.headline)
                        .foregroundColor(.white)
                        .fontWeight(.medium)
                        .multilineTextAlignment(.center)
                        .padding()
                    
                    Spacer()
                    
                    NavigationLink {
                        AdminLogin(showSignInView: $showSignInView)
                    } label: {
                        Text("Admin Login")
                            .font(.headline)
                            .foregroundColor(.purple)
                            .frame(height: 55)
                            .frame(maxWidth: .infinity)
                            .background(.white)
                            .cornerRadius(10)
                    }

                    
                    NavigationLink {
                        GuestDashboard()
                    } label: {
                        Text("Guest Login")
                            .foregroundColor(.white)
                            .fontWeight(.bold)
                            .frame(height: 55)
                            .frame(maxWidth: .infinity)
                            .background(.purple)
                            .cornerRadius(10)
                    }

                }
                .padding()
            }
        }
        
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        AuthenticationView(showSignInView: .constant(false))
    }
}
