//
//  AdminDashboard.swift
//  Imageo
//
//  Created by Yomi on 3/29/23.
//

import SwiftUI
import Firebase
import FirebaseStorage


final class AdminDashboardViewModel: ObservableObject{
    
    func logOut() throws{
       try  AuthenticationManager.shared.signOut()
    }
    
}

//struct PictureModel: Identifiable{
//    let id: String = UUID().uuidString
//    let pictureName: String
//}


struct AdminDashboard: View {
    
    
    @StateObject var viewModel = AdminDashboardViewModel()
    @Binding var showSignInView: Bool
    
    @State var shouldShowImagePicker = false
    @State var image: UIImage?
    
    @State var progressViewShow: Bool = false
    
    @State var imageDescription: String = ""
    
    let randomID = UUID.init().uuidString
    
    
    func upload(imageu: UIImage) {
        let storage = Storage.storage()
        let randomID = UUID.init().uuidString
        //storage reference
        let storageRef = storage.reference(withPath: "pictures/\(randomID).jpg")
        //resize image
        guard let resizedImage = imageu.jpegData(compressionQuality: 0.75) else { return }
        let uploadMetadata = StorageMetadata.init()
        uploadMetadata.contentType = "image/jpeg"
        
        let taskReference = storageRef.putData(resizedImage, metadata: uploadMetadata) { downloadMetadata, error in
            if let error = error{
                print("Error \(error.localizedDescription)")
                return
            }
            print("Upload was successful \(String(describing: downloadMetadata))")
            print("Picture Name = \(String(describing: downloadMetadata?.name))")
            progressViewShow = false
            
            //add the uploaded url to an array and save
            storageRef.downloadURL { url, error in
                if let error = error{
                    print("Got an error generating the URL: \(error.localizedDescription)")
                    return
                }
                if let url = url{
                    print("Here is your download URL: \(url.absoluteString)")
                }
            }
        }
        
        
        
        
        // to show progree of upload
        taskReference.observe(.progress) { snapshot in
            guard let pctThere = snapshot.progress?.fractionCompleted else { return }
            print("Uploading \(pctThere) complete")
        }
    }
    
    
    
    
    
    var body: some View {
        ZStack{
            //background
            RadialGradient(
                gradient: Gradient(colors: [Color.white, Color.gray]),
                center: .topLeading,
                startRadius: 1,
                endRadius: UIScreen.main.bounds.height
            )
            .ignoresSafeArea()
            
            VStack{
                Divider()
                    .foregroundColor(.white)
                Spacer()
                
                Button {
                    shouldShowImagePicker.toggle()
                } label: {
                    ZStack{
                        VStack{
                            if let image = self.image {
                                Image(uiImage: image)
                                    .resizable()
                                    .scaledToFit()
                                    .cornerRadius(20)
                                    .padding(.horizontal)
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 400)
                                    .shadow(radius: 10, y: -10)
                            } else {
                                Image(systemName: "photo.on.rectangle")
                                    .font(.system(size: 150))
                                    .padding()
                                    .foregroundColor(.gray)
                            }
                        }
                        if progressViewShow {
                            VStack{
                                ProgressView()
                                Text("Uploading, Please wait...")
                                    .font(.caption)
                                    .foregroundColor(.white)
                            }
                            .cornerRadius(10)
                            .frame(maxWidth: .infinity)
                            .padding(.horizontal)
                            .background(.cyan.opacity(0.1))
                            .padding()
                            
                        }
                    }
                }
                
                Spacer()
                
                Button {
                    Task{
                        do{
                            try viewModel.logOut()
                            showSignInView = true
                        }catch{
                            print("Error: \(error)")
                        }
                    }
                } label: {
                    Text("Signout")
                        .foregroundColor(.white)
                        .fontWeight(.bold)
                        .frame(height: 55)
                        .frame(maxWidth: .infinity)
                        .background(.purple)
                        .cornerRadius(10)
                        .padding()
                }

            }
            
        }
        .navigationBarItems(
            leading: HStack{
                Image(systemName: "photo.stack")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 20, height: 20)
                    .foregroundColor(.blue)
                Text("Image Library")
                    .font(.headline)
                    .foregroundColor(.blue)
            },
            trailing: HStack{
                Button {
                    upload(imageu: image!)
                    progressViewShow.toggle()
                } label: {
                    HStack(spacing: nil){
                        Image(systemName: "arrow.up.square.fill")
                            .foregroundColor(.blue)
                        Text("Upload")
                            .foregroundColor(.blue)
                            .font(.headline)
                    }
                    
                }
            })
        .fullScreenCover(isPresented: $shouldShowImagePicker, onDismiss: nil) {
                    ImagePicker(image: $image)
                        .ignoresSafeArea()
                }
    }
}

struct AdminDashboard_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack{
            AdminDashboard(showSignInView: .constant(false))
        }
    }
}


struct ImagePicker: UIViewControllerRepresentable {
 
    @Binding var image: UIImage?
 
    private let controller = UIImagePickerController()
 
    func makeCoordinator() -> Coordinator {
        return Coordinator(parent: self)
    }
 
    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
 
        let parent: ImagePicker
 
        init(parent: ImagePicker) {
            self.parent = parent
        }
 
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            parent.image = info[.originalImage] as? UIImage
            picker.dismiss(animated: true)
        }
 
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            picker.dismiss(animated: true)
        }
 
    }
 
    func makeUIViewController(context: Context) -> some UIViewController {
        controller.delegate = context.coordinator
        return controller
    }
 
    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {
 
    }

}
